Visit:

	 http://wiki.alliedmods.net/Category:Metamod:Source_Documentation 
	  
 for more information.


